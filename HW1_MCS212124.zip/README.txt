#####################################################################
#########  COL 761 - Frequent itemsets mining :ASSIGNMENT 1  ########
###############  (APRIORI AND FPTREE IPLEMENTATION)  ################
#####################################################################
#####################  TEAM MEMBERS  ################################
APAR SINGHAL(2021MCS2124) 
DEVESH KUMAR(2021MCS2130) 
SACHIN SINGH(2021MCS2149) 
Note: All members have equally contributed for assignment development
#####################################################################
#########################  FILES BUNDLED  ###########################
compile.sh - This shell script compile both cpp program mentioned above and running it generate executables which will the used by MCS212124.sh.

MCS212124.sh - This shell script will provide options to run the apiori or fptree algorithm given file and threshold, it also provides options to make plots of time taken by different algorithm in order to compare it.

install.sh - This shell script will clone the zip file of assignment 1 containing everything.

plot.py - It contains code for making plots depicting comparison between apriori and fptree algorithms according to parameter time taken with respect to different threshold in this list [5,10,25,50,90].

fptree.cpp - it implements the algorithm of fp tree based growth pattern mining.

apriori.cpp -it implements the algorithm of apriori based pattern mining.

######################### LANGUAGE USED: C++ ######################## 
#####################################################################
########################  HOW TO EXECUTE  ###########################
1. First run install.sh that will clone the zip file of assignment 1 containing everything.
2. Run compile.sh so that it produces all the exectables needed to run the whole program.
3. For running the main MCS212124.sh there are two options: 
	1st -> ./MCS212124.sh arg1 arg2 arg3 arg4 
		where arg1 can be '-apriori' or '-fptree', 
		arg2 is filename, 
		arg3 is support threshold in(%), 
		arg4 is filename in which output would be written. 
	2nd -> ./MCS212124.sh arg1 arg2 
		where arg2 is '-plot' which specifies plotting needs to be done.
		and arg1 is output filename (png file)
		
#####################################################################
######################### APRIORI ALGORITHM #########################
We have implemented apriori algorithm in c++ for given support and input file.
Apriori Algorithm (popular algorithm in data mining) is used to get frequent itemset from given list of transaction of items and given value of support.


#####################################################################
######################### FPTREE ALGORITHM ##########################
We have implemented fptree algorithm in c++ for given support and input file.FP tree algorithm is efficient and scalable method for mining the complete set of frequency.



#####################################################################
############################# ANALYSIS ##############################
We have observed that for low support the apriori and the fptree algorithm both time out.

We have also observed that for a support greater than 5% the fp tree algorithm runs treamdously faster than the apriori algorithm but the memory reqirement in fptree is sometimes higher than the apriori algorithm. the reason that fptree is faster because it avoids multiple passes over transactions and create a tree representation which can be mined to produce frequent items very fast. Whereas in Apriori, multiple passes over dataset is needed to eliminate infrequent itemsets at each and every level of pruning while fptree does only 2 passes to create a compressed tree representation from which frequent itemsets are mined quickly. Apriori requires generation of candidate itemsets, from where it mines the frequent ones but in fptree, no candidate generation is required. When the value of support are low, candidate itemsets in apriori increases exponentially compared to high support. So, running time also increases exponentially in apriori with decrease in threshold. 

#####################################################################







