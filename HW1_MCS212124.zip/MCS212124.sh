#!/bin/bash
if [ "$#" == 4 ]; then
    if [ "$1" == "-apriori" ]; then
        ./apriori "$2" "$3" "$4"
    fi
    if [ "$1" == "-fptree" ]; then
        ./fptree "$2" "$3" "$4"
    fi
fi

if [ "$#" == 3 ];then
    if [ "$1" == "-plot" ]; then
        python3 plot.py "$2" "$3"
    fi
fi