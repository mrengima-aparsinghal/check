#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <limits.h>
#include <unordered_map>
#include <set>
#include <cstring>
#include <sstream>
#include <algorithm>
// #include <bits/stdc++.h>
using namespace std;
struct Node {
   pair<int,int>data;
   vector<Node*>child;
   Node* parent;
};
Node *newNode(pair<int,int>data) {
   Node *temp = new Node;
   temp->data.first = data.first;
   temp->data.second = data.second;
   return temp;
}
map<int,int>m;
map<set<string>,int>res;
bool cmp(pair<int, int>&a,pair<int, int>&b){
        if(a.second==b.second){
            return a.first<b.first;
        }
        else{
            return a.second>b.second;
        }
}
bool cmp_table(pair<int, int>&a,pair<int, int>&b){
        if(a.second==b.second){
            return a.first<b.first;
        }
        else{
            return a.second<b.second;
        }
}
void make_tree(vector<pair<int,int>>v,Node*t,unordered_map<int,vector<Node*>>&table){
    int pt=0;
    for(int q=0;q<v.size();q++){
        pt=0;
        for(int p=0;p<t->child.size();p++){
            if(t->child[p]->data.first==v[q].first){
                t->child[p]->data.second++;
                t=t->child[p];
                // p=-1;
                pt=1;
                break;
            }
        }
        if(pt==0){
            while(q<v.size()){
                t->child.push_back(newNode({v[q].first,1}));
                // cout<<"kl"<<t->data.first<<" "<<t->child.size()<<"kl";
                table[v[q].first].push_back(t->child[t->child.size()-1]);
                t->child[t->child.size()-1]->parent=t;
                t=t->child[t->child.size()-1];
                q++;
            }
            break;
        }
    }
}

vector<vector<pair<int,int>>> make_set(vector<Node*>n,Node* t){
    vector<vector<pair<int,int>>>vf;
    int freq;
    for(auto a:n){
        freq=a->data.second;
        vector<pair<int,int>>v1;
        while(a->data.first!=INT_MIN){
            v1.push_back({a->data.first,freq});
            a=a->parent;
        }
        vf.push_back(v1);
    }
    return vf;
}
vector<vector<pair<int,int>>> verify_th(vector<vector<pair<int,int>>>vf,float th){
    int ff=0;
    for(auto f:vf){
        if(!f.empty()){
            ff=1;
        }
    }
    if(ff==0){
        return vf;
    }
    unordered_map<int,int>m_vf;
    for(auto a:vf){
        for(auto b:a){
            m_vf[b.first]+=b.second;
        }
    }
    vector<vector<pair<int,int>>>vf_copy;
    for(int i=0;i<vf.size();i++){
        vector<pair<int,int>>vf_copy_small;
        for(int j=0;j<vf[i].size();j++){
            if(m_vf[vf[i][j].first]>=th){
                vf_copy_small.push_back(vf[i][j]);
                // vf[i].erase(vf[i].begin()+j);
            }
        }
        vf_copy.push_back(vf_copy_small);
    }


    return vf_copy;
}
vector<vector<pair<int,int>>> erasing_ele(vector<vector<pair<int,int>>>whole_vec,int ele){
    vector<vector<pair<int,int>>>whole_vec1;
    for(int i=0;i<whole_vec.size();i++){
        for(int k=0;k<whole_vec[i].size();k++){
            if(whole_vec[i][k].first==ele){
                // v_mt.erase(v_mt.begin()+k);
                whole_vec[i].erase(whole_vec[i].begin()+k);
                whole_vec1.push_back(whole_vec[i]);
                break;
            }
        }
    }
    whole_vec.clear();//stored in copy vec
    whole_vec=whole_vec1;
    return whole_vec;
}
vector<vector<pair<int,int>>> erasing_single_ele(vector<vector<pair<int,int>>>whole_vec,int ele){
    // vector<vector<pair<int,int>>>whole_vec1;
    for(int i=0;i<whole_vec.size();i++){
        for(int k=0;k<whole_vec[i].size();k++){
            if(whole_vec[i][k].first==ele){
                // v_mt.erase(v_mt.begin()+k);
                whole_vec[i].erase(whole_vec[i].begin()+k);
                // whole_vec1.push_back(whole_vec[i]);
                break;
            }
        }
    }
    // whole_vec.clear();//stored in copy vec
    // whole_vec=whole_vec1;
    return whole_vec;
}
void mine_tree(vector<pair<int,int>> searching_vec,vector<vector<pair<int,int>>>whole_vec,float th,int searching_ele){
    //inserting into result
    set<string>s;
    for(auto a:searching_vec){
        // cout<<a.first<<" ";
        s.insert(to_string(a.first));
    }
    // cout<<endl;
    res[s]++;
    
    int ff=0;
    for(auto f:whole_vec){
        if(!f.empty()){
            ff=1;
        }
    }
    if(ff==0){
        return;
    }
    // mapping table
    set<int>temp_set;
    for(int i=0;i<whole_vec.size();i++){
        for(int j=0;j<whole_vec[i].size();j++){
            temp_set.insert(whole_vec[i][j].first);
        }
    }
    vector<pair<int,int>>temp_vec;
    for(auto a:temp_set){
        temp_vec.push_back({a,m[a]});
        
        //print remaining sets
    }
    sort(temp_vec.begin(),temp_vec.end(),cmp_table);//after removal of searching element ...unique elements in decreasing order 
    // cout<<"shcvjc";
    //apply function upon every unique element stored in temp_vec
    for(auto a:temp_vec){
        vector<pair<int,int>> searching_vec_copy=searching_vec;
        searching_vec_copy.push_back(a);
        searching_ele=a.first;
        vector<vector<pair<int,int>>> stored_vec=whole_vec;
        // vector<vector<pair<int,int>>> stored_vec=whole_vec;
        stored_vec=erasing_ele(stored_vec,searching_ele);
        stored_vec=verify_th(stored_vec,th);
        // stored_vec=erasing_ele(stored_vec,searching_ele);
        mine_tree(searching_vec_copy,stored_vec,th,searching_ele);
        whole_vec=erasing_single_ele(whole_vec,searching_ele);
        // break;
    }
} 
void freq_set(vector<vector<pair<int,int>>>v_mt,float th,int searching_ele){
    // cout<<"sicndlv"<<endl;
    v_mt=verify_th(v_mt,th);
    v_mt=erasing_ele(v_mt,searching_ele);
    vector<pair<int,int>> searching_vec;
    searching_vec.push_back({searching_ele,m[searching_ele]});
    mine_tree(searching_vec,v_mt,th,searching_ele);
    // cout<<"shcvjc";
}
int main(int argc, char* argv[]){
    string inputfilename=argv[1];
    float per=stof(argv[2]);
    string outputfilename=argv[3];
    unordered_map<int,vector<Node*>>table;
    vector<pair<int,vector<Node*>>>header_table;
    Node* temp=newNode({INT_MIN,0});
    temp->parent=NULL;
    // string filename("test3.dat");
    string line;
    ifstream input_file(inputfilename);
    ofstream file1;//output file
    file1.open(outputfilename);
    int c=0,first=0;
    float th;
    //line by line file read
    int lines=0;
    while (getline(input_file, line)){//for frequency count
        int num;  
        lines++;
        istringstream ls(line);
        set<int>faltu;//set for to delete duplicates from a row
        while (ls>>num){
            faltu.insert(num);
        }
        set<int>:: iterator f;
        for(f=faltu.begin();f!=faltu.end();f++){
            // cout<<*f<<" ";
            m[*f]++;
        }
    }
    // cout<<lines<<" ";
    th=(lines*(float)per)/100;

    //2nd time file read to perform operations 
    string filename1(inputfilename);
    string line1;
    ifstream input_file1(filename1);
    Node* t;
    while (getline(input_file1, line1)){
        int num;  
        istringstream ls(line1);
        vector<pair<int,int> >v;
        set<int>faltu;
        while (ls>>num){
            if(m[num]>=th){
                faltu.insert(num);
            }
        }
        set<int>:: iterator f;
        for(f=faltu.begin();f!=faltu.end();f++){
            v.push_back({*f,m[*f]});
        }
        sort(v.begin(),v.end(),cmp);

        //tree implementation
        t=temp;
        make_tree(v,t,table);
        
         
    }
    // treeprint(temp);
    // call(temp);


    //header table in decreasing freq
    vector<pair<int,int>>vt;
    for(auto a:table){
        vt.push_back({a.first,m[a.first]});
    }
    sort(vt.begin(),vt.end(),cmp_table);
    for(int i=0;i<vt.size();i++){
        header_table.push_back({vt[i].first,table[vt[i].first]});
    }
    for(auto a:header_table){
        vector<vector<pair<int,int>>>v_mt;
        v_mt=make_set(a.second,temp);
        freq_set(v_mt,th,a.first);
    }
    // cout<<res.size();
    for(auto a:res){
        for(auto b:a.first){
            // cout<<b<<" ";
            file1<<b<<" ";
        }
        file1<<endl;
        // cout<<endl;
    }
    // cout<<lines<<" "<<per<<" "<<th;
    return 0;
}