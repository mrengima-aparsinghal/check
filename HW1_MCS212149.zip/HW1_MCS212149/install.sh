git clone https://github.com/Shiva843/Abraca-data.git
cd Abraca-data
unzip HW1_MCS212149.zip
cd HW1_MCS212149
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
module load compiler/gcc/7.1.0/compilervars
module load compiler/python/3.6.0/ucs4/gnu/447