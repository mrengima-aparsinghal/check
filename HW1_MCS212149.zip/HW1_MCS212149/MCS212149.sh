#!/bin/bash
#Here $1 specifies input file here, $2 specifies threshold for algos and plot for plotting
#$3 specifies which algo to use and $4 specifies out file in which results will be written
if [ "$1" == "-fptree" ]; then
	./fptree "$2" "$3" "$4"
elif [ "$1" == "-apriori" ]; then
 	./apriori "$2" "$3" "$4"
elif [ "$1" == "-plot" ]; then
	timeout 60m python3 plot.py "$2" "$3"
else
	echo "Please provide the valid argument"
fi