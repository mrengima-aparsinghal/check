#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <cmath>
#include <set>
#include <cstring>
#include <sstream>
#include <algorithm>
// #include <bits/stdc++.h>
using namespace std;
set<int> make_pair(set<int> s1,set<int> s2){
   set<int>sf;
   set<int>:: iterator set1=s1.begin();
   set<int>:: iterator set2=s2.begin();
   int set_ele=0;
   bool flag;
   int ss=s1.size();
   int set1_last_ele,set2_last_ele;
   while(set1!=s1.end()){
      if(*set1!=*set2){
         sf.insert(*set1);
         sf.insert(*set2);
         break;
      }
      sf.insert(*set1);
      set_ele++;
      set1++;
      set2++;
   }
   if(set_ele+1==ss && set_ele+1==s2.size()){
      flag=true;
   }
   else{
      flag=false;
   }
   if(flag==false){
      sf.clear();
   }
   return sf;
}
void freq_count(map<set<int>,int>&temp,string inputfilename){
   string filename(inputfilename);
      string line;
      ifstream input_file(filename);
      int c=0;
      //line by line file read
      while (getline(input_file, line)){
         int num;
         map<int, int>transaction;  
         istringstream ls(line);
         while (ls>>num){
            transaction[num]++;
         }
         for(auto a:temp){
            int g=0;
            for(auto b:a.first){
               if(transaction[b]==0){
                  g=1;
                  break;
               }
            }
            if(g==0){
               temp[a.first]++;
            }
         }
      }
      // cout<<"enter"<<th;
      for(auto a:temp){
         a.second--;
      }
}
void erasing_map_ele(map<set<int>,int>&t,float th){
   vector<pair<set<int>,int>>v;
   int m=ceil(th);
   map<set<int>,int>mp;
   for(auto a:t){
      if(a.second>=m){
         mp.insert(a);
      }
   }
   t=mp;
}
int main(int argc,char* argv[])
{  
   string inputfilename=argv[1];
   float per=stof(argv[2]);  
   string outputfilename=argv[3];
   map<set<string>,int>mf;
   set<string>s_final;
   float th;
//    // map<set<string>,int>mf;
   // string filename("test3.dat");
   string line;
   ifstream input_file(inputfilename);
   ofstream file1;//output file
   file1.open(outputfilename);
   int num,lines=0;
   map<set<int>, int>m;
   map<set<int>, int>m1;
   
   //  len-1 Candidate set
   while (getline(input_file, line)){//for frequency count
        int num;  
        lines++;
        istringstream ls(line);
        set<int>faltu;//set for to delete duplicates from a row
        while (ls>>num){
            faltu.insert(num);
        }
        set<int>:: iterator f;
        for(f=faltu.begin();f!=faltu.end();f++){
            // cout<<*f<<" ";
            set<int>s;
            s.insert(*f);
            m[s]++;
            s.clear();
        }
    }
    th=(per*lines)/100;
    map<set<int>, int>:: iterator it=m.begin();
    erasing_map_ele(m,th);
    set<string>s_final1;
    for(auto a:m){
      for(auto b:a.first){
         s_final1.insert(to_string(b));
         mf[s_final1]++;
         s_final1.clear();
         // cout<<b<<" ";
      }
      // cout
    }
   int n=m.size();
   while(n!=0 && m.size()!=0 && m.size()!=1){
      it=m.begin();
      map<set<int>,int>temp;
      for(auto i:m){
         it++;
         map<set<int>, int>:: iterator it_next=it;
         while(it_next!=m.end()){
            set<int>set_size_plus;
            set_size_plus=make_pair(i.first,it_next->first);
            if(!set_size_plus.empty()){
               temp[set_size_plus]=0;
            }
            it_next++;
         }
      }
      
      freq_count(temp,inputfilename);
      erasing_map_ele(temp,th);
      
      set<string>s_temp;
      for(auto a:temp){
         for(auto b:a.first){
            s_temp.insert(to_string(b));
         }
         mf[s_temp]++;
         s_temp.clear();
      }
      m=temp;
      temp.clear();
      n--;
      // break;
   }
   for(auto a:mf){
      for(auto b:a.first){
         // cout<<b<<" ";
         file1<<b<<" ";
      }
      file1<<endl;
      // cout<<endl;
   }
   // cout<<lines<<" "<<th;
   return 0;
}