---------------------Data Mining-COL761-Homework 1------------
Apriori Algorithm and Frequent Pattern Growth Algorithm 
Both of the above algorithms are used to find frequent itemsets in a given set of transactions. They are used in recommendation systems and other similar systems.

Files-
The files that we are submitting are: install.sh, apr.cpp, fp.cpp, 2021MCS2149.sh, plot.py

2021MCS2149.sh : This is a bash script that describes the method to run both the Apriori and FP Tree algorithm. The inputs are also described in this file as well. This is main source of execution. This can also be used for plotting the values and comparing the Apriori and FP Tree algorithm.


-------Apriori Algorithm--------
apr.cpp contains the code for Apriori algorithm and it takes input through command and outputs the value in a file.

--Frequent Pattern Growth Algorithm-------

fp.cpp contains the code for FP growth algorithm and it takes input through command line and provides the mined frequent sets in an output file



---------------Observations-----------------
We have run both the algorithms for different values of supports and observed the following things:
1. When the dataset is large enough, both the algorithms take a high amount of time when the support is low.
2. For bigger value of supports, FP growth algorithm works significantly better than Apriori Algorithm on the same dataset, provided that the FP Tree can be stored in the main memory.
3. FP Tree is faster because it does not need to scan through the file again and again.
4. The memory requirement of FP growth is higher than Apriori because the tree stays in the main memory.

TEAM MEMBERS-
2021MCS2149- Shiva(33%)
2021MCS2151- Shivankar Garg(33%)
2021MCS2143- Nutan Singh(33%)