#!/bin/bash
g++ apriori.cpp -o apriori -std="c++11" -o3
g++ fptree.cpp -o fptree -std="c++11" -o3