import time
import os
from matplotlib import pyplot as plt
import sys

script = "sh MCS212149.sh"
input_file = sys.argv[1]
output_file = sys.argv[2]
support = [90,50,25,10,5]
apriori = []
fptree = []

for i in support:
	s=time.time()
	os.system(script+" -apriori"+" "+input_file+" "+str(i)+" "+output_file)
	e=time.time()
	apriori.append(e-s)
	# print(i)

for i in support:
	st=time.time()
	os.system(script+" -fptree"+" "+input_file+" "+str(i)+" "+output_file)
	et=time.time()
	fptree.append(et-st)
	# print(i)

plt.figure()
plt.plot(support, apriori, label='Apriori')
plt.plot(support, fptree, label='FP-tree')
plt.title('Running time Comparasion')
plt.xlabel('Support threshold')
plt.ylabel('Running Times(s)')
plt.legend()
plt.savefig(output_file+".png")
    